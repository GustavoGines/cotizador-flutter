package com.example.cotizador_dolar_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
